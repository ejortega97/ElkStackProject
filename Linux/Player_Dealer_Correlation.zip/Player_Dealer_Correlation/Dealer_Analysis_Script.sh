
awk '{print $1, $2, $5, $6}' $1 >> Dealers_working_during_losses
